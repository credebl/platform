/* eslint-disable camelcase */
import { HttpException, Inject, Injectable, Logger } from '@nestjs/common';
import { IUsersActivity } from '../interfaces';
import { PrismaService } from '@credebl/prisma-service';
// eslint-disable-next-line camelcase
import { user_activity, RecordType } from '@prisma/client';
// eslint-disable-next-line camelcase
import type { user } from '@prisma/client';
import { map } from 'rxjs';
import { ClientProxy } from '@nestjs/microservices';

@Injectable()
export class UserActivityRepository {
  private readonly logger: Logger;
  constructor(
    private readonly prisma: PrismaService,
    @Inject('NATS_CLIENT') private readonly userActivityServiceProxy: ClientProxy
  ) {
    this.logger = new Logger('UserActivityRepository');
  }

  async logActivity(userId: string, orgId: string, action: string, details: string): Promise<user_activity> {
    return this.prisma.user_activity.create({
      data: {
        userId,
        orgId,
        action,
        details,
        createdBy: userId,
        lastChangedBy: userId
      }
    });
  }

  async getRecentActivities(userId: string, limit: number): Promise<IUsersActivity[]> {
    return this.prisma.user_activity.findMany({
      where: {
        userId
      },
      select: {
        id: true,
        userId: true,
        orgId: true,
        action: true,
        details: true,
        createDateTime: true,
        lastChangedDateTime: true
      },
      orderBy: {
        createDateTime: 'desc'
      },
      take: limit
    });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async _orgDeletedActivity(orgId: string, user: user, txnMetadata: object, recordType: RecordType): Promise<any> {
    try {
      const pattern = { cmd: 'org-deleted-activity' };
      const payload = { orgId, userId: user?.id, deletedBy: user?.id, recordType, userEmail: user?.email, txnMetadata };

      return this.userActivityServiceProxy
        .send<string>(pattern, payload)
        .pipe(
          map((message) => ({
            message
          }))
        )
        .toPromise()
        .catch((error) => {
          this.logger.error(`catch: ${JSON.stringify(error)}`);

          throw new HttpException(
            {
              status: error?.error?.statusCode,
              error: error?.error?.error,
              message: error?.error?.message ?? error?.message
            },
            error.error
          );
        });
    } catch (error) {
      this.logger.error(`[_orgDeletedActivity] - error in delete wallet : ${JSON.stringify(error)}`);
      throw error;
    }
  }
}
